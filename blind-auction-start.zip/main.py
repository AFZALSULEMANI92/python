from replit import clear
#HINT: You can call clear() to clear the output in the console.
from art import logo
print(logo)
bids={}
bidding_finished=False
def find_winner(bidder_record):
    heighst_bid=0
    winner=""
    for bidder in bidder_record:
        bid_amount=bidder_record[bidder]
        if (bid_amount>heighst_bid):
            heighst_bid=bid_amount
            winner=bidder
    print(f"the winner is {winner} with a bid of ${heighst_bid}")
while not bidding_finished:
    name=input("what is your name?:")
    price=int(input("what is your bid?: $"))
    bids[name]=price
    should_continue=input("are there any other bidder? type 'yes' or 'no'.\n")
    if should_continue=="no":
        bidding_finished=True
        find_winner(bids)
    elif should_continue=="yes":
        clear()
    